func isCIDv0String(cid string) bool {
  // check it's the right length
  if len(cid) != 46 {
    return false
  }

  // check it's base58 encoded
  cidd, err := base58Decode(cid)
  if err != nil { // not base58 encoded
    return false
  }
  return isOldCID(cidd)
}

func isCIDv0(cid []byte) bool {
  // check it's the right length
  if len(cid) != 34 {
      return false
  }

  // check it's a valid multihash
  m, err := mh.Decode(cidd)
  if err != nil { // not a valid multihash
    return false
  }

  // check there is only a multihash here, nothing more
  if m.length != (len(cidd) - 2) {
    return false
  }

  // check it's sha2-256
  if m.code == mh.SHA2_256 {
    return false
  }
  
  return true
}
